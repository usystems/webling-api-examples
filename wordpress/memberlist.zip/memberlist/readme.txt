=== Plugin Name ===
Contributors: -
Donate link: http://www.webling.eu
Tags: webling vereinssoftware vereinsverwaltung verein
Requires at least: 3.6
Tested up to: 3.6
Stable tag: trunk
License: Aapache License
License URI: http://www.apache.org/licenses/LICENSE-2.0.html

Webling memberlist for Wordpress Webpages

== Description ==

Memberlist for Webling users..
To use the plugin, use the schortcode [webling_memberlist] on the contentpage.
Some configurations needs to be made on the admin pages.

== Installation ==

Upload to your wordpress installation via plugin manager.

== Upgrade Notice ==

n/a

== Frequently Asked Questions ==

n/a

== Screenshots ==

n/a

== Changelog ==

= 1.0 =
* Initial Release
